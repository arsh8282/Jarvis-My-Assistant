import webbrowser
from typing import Tuple, Optional
from jarvis.app_launcher import AppLauncher


class ActionManager:
    """
    Executes user-approved Android intents and actions safely. Never performs hidden
    UI automation or unauthorized account actions.
    """

    def __init__(self, app_launcher: AppLauncher):
        self.app_launcher = app_launcher

    def detect_and_prepare_action(self, user_text: str) -> Optional[dict]:
        lower = (user_text or "").strip().lower()
        if lower.startswith("open "):
            target = user_text.strip()[5:].strip().rstrip(".")
            if target.startswith("http://") or target.startswith("https://"):
                return {"type": "OPEN_URL", "target": target, "requires_confirmation": True}
            return {"type": "OPEN_APP", "target": target, "requires_confirmation": False}
        return None

    def execute_action(self, action: dict) -> Tuple[bool, str]:
        atype = action.get("type")
        target = action.get("target", "")
        if atype == "OPEN_APP":
            return self.app_launcher.open_app_by_query(target)
        if atype == "OPEN_URL":
            try:
                webbrowser.open(target)
                return True, f"Opened link in browser: {target}"
            except Exception as e:
                return False, f"Could not open URL: {e}"
        return False, "Unsupported action type."