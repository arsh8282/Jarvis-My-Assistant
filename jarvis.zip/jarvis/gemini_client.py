import base64
import threading
import requests
from typing import Dict, Any, List, Optional, Tuple
from jarvis.utils import redact_secrets, logger

GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


class GeminiAPIError(Exception):
    def __init__(self, category: str, message: str, status_code: int = 0):
        super().__init__(message)
        self.category = category
        self.user_message = redact_secrets(message)
        self.status_code = status_code


class GeminiClient:
    """
    Thread-safe Gemini REST API client supporting dynamic model listing,
    text generation, multimodal image analysis, system instructions, and cancellation.
    """

    def __init__(self, timeout: int = 35):
        self.timeout = timeout
        self._cancel_event = threading.Event()
        self._active_lock = threading.Lock()
        self._request_in_flight = False

    def is_busy(self) -> bool:
        with self._active_lock:
            return self._request_in_flight

    def cancel_active_request(self) -> None:
        self._cancel_event.set()

    def _headers(self, api_key: str) -> Dict[str, str]:
        return {
            "Content-Type": "application/json",
            "x-goog-api-key": api_key.strip(),
        }

    def list_models(self, api_key: str) -> List[Dict[str, Any]]:
        """Fetches all available models dynamically from the v1beta/models endpoint with pagination."""
        if not api_key or not api_key.strip():
            raise GeminiAPIError("AUTH_ERROR", "API key is empty. Please enter a valid Gemini API key.")

        models: List[Dict[str, Any]] = []
        page_token: Optional[str] = None

        while True:
            params: Dict[str, Any] = {"pageSize": 50}
            if page_token:
                params["pageToken"] = page_token

            try:
                resp = requests.get(
                    f"{GEMINI_BASE_URL}/models",
                    headers=self._headers(api_key),
                    params=params,
                    timeout=self.timeout,
                )
            except requests.exceptions.Timeout:
                raise GeminiAPIError("TIMEOUT", "Connection timed out while fetching models.")
            except requests.exceptions.ConnectionError:
                raise GeminiAPIError("NETWORK_ERROR", "No internet connection or unable to reach Google Gemini servers.")
            except Exception as e:
                raise GeminiAPIError("UNKNOWN_ERROR", f"Network error: {redact_secrets(str(e))}")

            if resp.status_code in (400, 401, 403):
                raise GeminiAPIError("AUTH_ERROR", "Invalid or unauthorized Gemini API key.", resp.status_code)
            if resp.status_code == 429:
                raise GeminiAPIError("QUOTA_ERROR", "API quota or rate limit exceeded.", 429)
            if resp.status_code != 200:
                raise GeminiAPIError("API_ERROR", f"Server returned HTTP {resp.status_code}.", resp.status_code)

            try:
                payload = resp.json()
            except ValueError:
                raise GeminiAPIError("PARSE_ERROR", "Malformed JSON received from Gemini model list endpoint.")

            for raw_model in payload.get("models", []):
                methods = raw_model.get("supportedGenerationMethods", [])
                if "generateContent" not in methods:
                    continue
                name = raw_model.get("name", "")
                short_name = name.replace("models/", "")
                # Identify multimodal capability based on official Gemini model families
                supports_vision = any(
                    tag in short_name.lower()
                    for tag in ("gemini-1.5", "gemini-2.0", "gemini-2.5", "gemini-pro-vision", "flash", "pro")
                )
                models.append(
                    {
                        "name": short_name,
                        "display_name": raw_model.get("displayName", short_name),
                        "description": raw_model.get("description", ""),
                        "input_token_limit": raw_model.get("inputTokenLimit", 32768),
                        "output_token_limit": raw_model.get("outputTokenLimit", 8192),
                        "supports_generate": True,
                        "supports_vision": supports_vision,
                    }
                )

            page_token = payload.get("nextPageToken")
            if not page_token:
                break

        if not models:
            raise GeminiAPIError("NO_MODELS", "No content-generation models found for this API key.")
        return models

    def generate_response(
        self,
        api_key: str,
        model_name: str,
        prompt_text: str,
        system_instruction: str = "",
        history: Optional[List[Dict[str, str]]] = None,
        image_bytes: Optional[bytes] = None,
        image_mime: str = "image/jpeg",
    ) -> str:
        """Sends a text or multimodal prompt to the selected Gemini model."""
        if not api_key or not api_key.strip():
            raise GeminiAPIError("AUTH_ERROR", "Missing Gemini API key.")
        if not model_name:
            raise GeminiAPIError("MODEL_ERROR", "No Gemini model selected.")

        with self._active_lock:
            if self._request_in_flight:
                raise GeminiAPIError("BUSY", "A request is already in progress. Please wait or cancel it.")
            self._request_in_flight = True
            self._cancel_event.clear()

        try:
            clean_model = model_name.replace("models/", "")
            url = f"{GEMINI_BASE_URL}/models/{clean_model}:generateContent"

            contents: List[Dict[str, Any]] = []
            if history:
                for item in history:
                    role = "user" if item.get("role") == "user" else "model"
                    text = item.get("content", "")
                    if text:
                        contents.append({"role": role, "parts": [{"text": text}]})

            user_parts: List[Dict[str, Any]] = []
            if image_bytes:
                b64_img = base64.b64encode(image_bytes).decode("ascii")
                user_parts.append({"inline_data": {"mime_type": image_mime, "data": b64_img}})
            user_parts.append({"text": prompt_text})
            contents.append({"role": "user", "parts": user_parts})

            body: Dict[str, Any] = {
                "contents": contents,
                "generationConfig": {"temperature": 0.4, "maxOutputTokens": 4096},
            }
            if system_instruction and system_instruction.strip():
                body["systemInstruction"] = {"parts": [{"text": system_instruction.strip()}]}

            resp = requests.post(url, headers=self._headers(api_key), json=body, timeout=self.timeout)

            if self._cancel_event.is_set():
                raise GeminiAPIError("CANCELLED", "Request cancelled by user.")

            if resp.status_code in (401, 403):
                raise GeminiAPIError("AUTH_ERROR", "API key rejected by server. Check your key in Settings.", resp.status_code)
            if resp.status_code == 404:
                raise GeminiAPIError("MODEL_UNAVAILABLE", f"Model '{clean_model}' is unavailable or deprecated.", 404)
            if resp.status_code == 429:
                raise GeminiAPIError("QUOTA_ERROR", "Rate limit or quota reached. Please wait a moment and retry.", 429)
            if resp.status_code != 200:
                err_detail = ""
                try:
                    err_detail = resp.json().get("error", {}).get("message", "")
                except Exception:
                    pass
                raise GeminiAPIError("API_ERROR", f"Gemini error ({resp.status_code}): {err_detail}", resp.status_code)

            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                block_reason = data.get("promptFeedback", {}).get("blockReason", "Empty response")
                raise GeminiAPIError("EMPTY_RESPONSE", f"No response returned ({block_reason}).")

            parts = candidates[0].get("content", {}).get("parts", [])
            text_segments = [p.get("text", "") for p in parts if "text" in p]
            final_text = "\n".join(text_segments).strip()
            if not final_text:
                raise GeminiAPIError("EMPTY_RESPONSE", "Model returned an empty text candidate.")
            return final_text

        except GeminiAPIError:
            raise
        except requests.exceptions.Timeout:
            raise GeminiAPIError("TIMEOUT", "Request timed out. Check your connection or increase timeout in Settings.")
        except requests.exceptions.ConnectionError:
            raise GeminiAPIError("NETWORK_ERROR", "Network unreachable. Please check your internet connection.")
        except Exception as e:
            logger.error(f"Unexpected Gemini client error: {e}")
            raise GeminiAPIError("UNKNOWN_ERROR", f"Request failed: {redact_secrets(str(e))}")
        finally:
            with self._active_lock:
                self._request_in_flight = False