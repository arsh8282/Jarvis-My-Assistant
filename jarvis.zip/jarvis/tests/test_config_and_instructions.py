import tempfile  
from jarvis.config import ConfigManager  
from jarvis.instructions import InstructionManager, DEFAULT_SYSTEM_INSTRUCTIONS  
from jarvis.security import SecureKeyStorage  
from jarvis.utils import redact_secrets, summarize_code_for_speech  
  
  
def test_config_persistence():  
    with tempfile.TemporaryDirectory() as tmp:  
        cfg = ConfigManager(tmp)  
        assert cfg.get("speech_auto_enabled") is True  
        cfg.set("speech_auto_enabled", False)  
  
        cfg2 = ConfigManager(tmp)  
        assert cfg2.get("speech_auto_enabled") is False  
  
  
def test_custom_instructions_validation_and_restore():  
    with tempfile.TemporaryDirectory() as tmp:  
        im = InstructionManager(tmp)  
        assert "Address me as Sir" in im.get_active()  
  
        ok, _ = im.save_custom("   ")  
        assert ok is False  
  
        ok, _ = im.save_custom("Custom Modder Persona")  
        assert ok is True  
        assert im.get_active() == "Custom Modder Persona"  
  
        restored = im.restore_default()  
        assert restored == DEFAULT_SYSTEM_INSTRUCTIONS  
  
  
def test_secure_storage_fallback_and_log_redaction():  
    with tempfile.TemporaryDirectory() as tmp:  
        sec = SecureKeyStorage(tmp, android_bridge=None)  
        fake_key = "AIzaSyD9999999999999999999999999999"  
        assert sec.save_api_key(fake_key) is True  
        assert sec.load_api_key() == fake_key  
  
        redacted = redact_secrets(f"Error with key {fake_key}")  
        assert fake_key not in redacted  
        assert "AIza[REDACTED_KEY]" in redacted  
  
  
def test_code_speech_summarizer():  
    md = "Here is the fix:\n```smali\n.locals 2\nif-eqz v0, :cond_0\n```"  
    spoken = summarize_code_for_speech(md)  
    assert "reserves 2 local registers" in spoken  
    assert "if-equal-to-zero" in spoken  
  