import tempfile  
from unittest.mock import patch, MagicMock  
import pytest  
from jarvis.gemini_client import GeminiClient, GeminiAPIError  
from jarvis.database import ConversationDatabase  
from jarvis.config import ConfigManager  
from jarvis.model_manager import ModelManager  
from jarvis.conversation import ConversationManager  
  
  
@patch("jarvis.gemini_client.requests.get")  
def test_dynamic_model_discovery(mock_get):  
    mock_resp = MagicMock()  
    mock_resp.status_code = 200  
    mock_resp.json.return_value = {  
        "models": [  
            {  
                "name": "models/gemini-2.5-flash",  
                "displayName": "Gemini 2.5 Flash",  
                "supportedGenerationMethods": ["generateContent"],  
            },  
            {  
                "name": "models/embedding-001",  
                "displayName": "Embedding",  
                "supportedGenerationMethods": ["embedContent"],  
            },  
        ]  
    }  
    mock_get.return_value = mock_resp  
  
    with tempfile.TemporaryDirectory() as tmp:  
        client = GeminiClient()  
        db = ConversationDatabase(tmp)  
        cfg = ConfigManager(tmp)  
        mm = ModelManager(client, db, cfg)  
  
        models = mm.refresh_models("fake_key")  
        assert len(models) == 1  
        assert models[0]["name"] == "gemini-2.5-flash"  
        assert models[0]["supports_vision"] is True  
  
  
def test_conversation_trimming():  
    with tempfile.TemporaryDirectory() as tmp:  
        db = ConversationDatabase(tmp)  
        cfg = ConfigManager(tmp)  
        cfg.set("max_history_messages", 4)  
        conv = ConversationManager(db, cfg)  
  
        conv.add_turn("u1", "a1")  
        conv.add_turn("u2", "a2")  
        conv.add_turn("u3", "a3")  
  
        ctx = conv.get_trimmed_context()  
        assert len(ctx) == 4  
        assert ctx[0]["content"] == "u2"  
  