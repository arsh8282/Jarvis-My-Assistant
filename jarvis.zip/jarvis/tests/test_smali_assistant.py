from jarvis.smali_assistant import SmaliAssistant  
  
  
def test_smali_false_branch_and_register_bounds():  
    sample = """  
    .locals 1  
    const/4 v0, 0x0  
    if-eqz v0, :cond_false  
    const/4 v1, 0x1  
    :cond_false  
    return-void  
    """  
    assistant = SmaliAssistant()  
    res = assistant.inspect_registers_and_branches(sample)  
  
    assert res["locals_declared"] == 1  
    assert "v0" in res["local_registers_used"]  
    assert "v1" in res["local_registers_used"]  
    assert len(res["branches"]) == 1  
    assert res["branches"][0]["opcode"] == "if-eqz"  
    assert res["branches"][0]["target"] == ":cond_false"  
    # Because .locals is 1 (only v0 is valid), using v1 must flag a VerifyError warning:  
    assert any("v1 is used" in issue for issue in res["issues"])  
  
  
def test_smali_missing_label_detection():  
    sample = """  
    .locals 2  
    const/4 v0, 0x0  
    if-nez v0, :missing_target  
    return-void  
    """  
    assistant = SmaliAssistant()  
    res = assistant.inspect_registers_and_branches(sample)  
    assert any(":missing_target" in issue for issue in res["issues"])  
  