package org.jarvis.bridge;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class JarvisFloatingService {
    private static WindowManager windowManager;
    private static LinearLayout floatingRoot;
    private static LinearLayout expandedBox;
    private static boolean isShowing = false;
    private static String pendingCommand = "";

    public static void showFloatingOverlay(final Context context) {
        if (isShowing || !JarvisBridge.canDrawOverlays(context)) return;

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
                    int layoutFlag = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE;

                    final WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            layoutFlag,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                            PixelFormat.TRANSLUCENT);
                    params.gravity = Gravity.TOP | Gravity.START;
                    params.x = 40;
                    params.y = 220;

                    floatingRoot = new LinearLayout(context);
                    floatingRoot.setOrientation(LinearLayout.VERTICAL);
                    GradientDrawable bg = new GradientDrawable();
                    bg.setColor(Color.parseColor("#E60A192F"));
                    bg.setCornerRadius(28f);
                    bg.setStroke(3, Color.parseColor("#00E5FF"));
                    floatingRoot.setBackground(bg);
                    floatingRoot.setPadding(20, 16, 20, 16);

                    TextView badge = new TextView(context);
                    badge.setText("JARVIS");
                    badge.setTextColor(Color.parseColor("#00E5FF"));
                    badge.setTextSize(14f);
                    floatingRoot.addView(badge);

                    expandedBox = new LinearLayout(context);
                    expandedBox.setOrientation(LinearLayout.VERTICAL);
                    expandedBox.setVisibility(View.GONE);

                    Button btnVoice = createButton(context, "Mic Input", "VOICE_TRIGGER");
                    Button btnScreen = createButton(context, "Analyze Screen", "SCREEN_VISION");
                    Button btnStopSpeech = createButton(context, "Stop Speech", "STOP_SPEECH");
                    Button btnOpenApp = createButton(context, "Open JARVIS", "OPEN_MAIN");
                    Button btnClose = createButton(context, "Close Overlay", "CLOSE_OVERLAY");

                    expandedBox.addView(btnVoice);
                    expandedBox.addView(btnScreen);
                    expandedBox.addView(btnStopSpeech);
                    expandedBox.addView(btnOpenApp);
                    expandedBox.addView(btnClose);
                    floatingRoot.addView(expandedBox);

                    badge.setOnTouchListener(new View.OnTouchListener() {
                        private int initialX, initialY;
                        private float initialTouchX, initialTouchY;
                        private long downTime;

                        @Override
                        public boolean onTouch(View v, MotionEvent event) {
                            switch (event.getAction()) {
                                case MotionEvent.ACTION_DOWN:
                                    downTime = System.currentTimeMillis();
                                    initialX = params.x;
                                    initialY = params.y;
                                    initialTouchX = event.getRawX();
                                    initialTouchY = event.getRawY();
                                    return true;
                                case MotionEvent.ACTION_MOVE:
                                    params.x = initialX + (int) (event.getRawX() - initialTouchX);
                                    params.y = initialY + (int) (event.getRawY() - initialTouchY);
                                    if (windowManager != null && floatingRoot != null) {
                                        windowManager.updateViewLayout(floatingRoot, params);
                                    }
                                    return true;
                                case MotionEvent.ACTION_UP:
                                    if (System.currentTimeMillis() - downTime < 220) {
                                        expandedBox.setVisibility(
                                                expandedBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE
                                        );
                                    }
                                    return true;
                            }
                            return false;
                        }
                    });

                    windowManager.addView(floatingRoot, params);
                    isShowing = true;
                } catch (Exception ignored) {}
            }
        });
    }

    private static Button createButton(final Context context, String label, final String cmd) {
        Button b = new Button(context);
        b.setText(label);
        b.setTextSize(11f);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#112240"));
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ("CLOSE_OVERLAY".equals(cmd)) {
                    hideFloatingOverlay();
                } else if ("STOP_SPEECH".equals(cmd)) {
                    JarvisBridge.stopTTS();
                } else if ("OPEN_MAIN".equals(cmd)) {
                    Intent launch = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        context.startActivity(launch);
                    }
                } else {
                    pendingCommand = cmd;
                }
            }
        });
        return b;
    }

    public static void hideFloatingOverlay() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (isShowing && windowManager != null && floatingRoot != null) {
                        windowManager.removeView(floatingRoot);
                    }
                } catch (Exception ignored) {}
                isShowing = false;
            }
        });
    }

    public static boolean isOverlayActive() {
        return isShowing;
    }

    public static String pollPendingCommand() {
        String cmd = pendingCommand;
        pendingCommand = "";
        return cmd;
    }
}