package org.jarvis.bridge;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

public class JarvisBridge {
    private static final String KEYSTORE_ALIAS = "JarvisGeminiSecretKey";
    private static final String PREFS_NAME = "jarvis_secure_prefs";
    private static TextToSpeech ttsInstance;
    private static boolean ttsReady = false;
    private static SpeechRecognizer speechRecognizer;
    private static String lastSpeechStatus = "IDLE";
    private static String lastRecognizedText = "";
    private static String lastSpeechError = "";

    // 1. Hardware-backed AES-GCM KeyStore encryption for API Key
    public static boolean saveEncryptedSecret(Context context, String keyName, String plainText) {
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (!keyStore.containsAlias(KEYSTORE_ALIAS)) {
                KeyGenerator keyGenerator = KeyGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
                keyGenerator.init(new KeyGenParameterSpec.Builder(
                        KEYSTORE_ALIAS,
                        KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .build());
                keyGenerator.generateKey();
            }
            SecretKey secretKey = ((KeyStore.SecretKeyEntry) keyStore.getEntry(KEYSTORE_ALIAS, null)).getSecretKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

            String combined = Base64.encodeToString(iv, Base64.NO_WRAP) + ":" +
                              Base64.encodeToString(encrypted, Base64.NO_WRAP);
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(keyName, combined).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static String loadEncryptedSecret(Context context, String keyName) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String combined = prefs.getString(keyName, null);
            if (combined == null || !combined.contains(":")) return "";

            String[] parts = combined.split(":");
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(parts[1], Base64.NO_WRAP);

            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            SecretKey secretKey = ((KeyStore.SecretKeyEntry) keyStore.getEntry(KEYSTORE_ALIAS, null)).getSecretKey();

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec spec = new GCMParameterSpec(128, iv);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, spec);
            byte[] decrypted = cipher.doFinal(encrypted);
            return new String(decrypted, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    public static void clearEncryptedSecret(Context context, String keyName) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(keyName).apply();
    }

    // 2. Android Native TextToSpeech Bridge
    public static void initTTS(final Context context) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (ttsInstance != null) return;
                ttsInstance = new TextToSpeech(context.getApplicationContext(), new TextToSpeech.OnInitListener() {
                    @Override
                    public void onInit(int status) {
                        if (status == TextToSpeech.SUCCESS) {
                            ttsInstance.setLanguage(Locale.US);
                            ttsReady = true;
                        }
                    }
                });
            }
        });
    }

    public static boolean speakText(final String text, final float rate, final float pitch, final boolean flush) {
        if (ttsInstance == null || !ttsReady) return false;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                ttsInstance.setSpeechRate(rate);
                ttsInstance.setPitch(pitch);
                int queueMode = flush ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD;
                ttsInstance.speak(text, queueMode, null, "jarvis_utt_" + System.currentTimeMillis());
            }
        });
        return true;
    }

    public static void stopTTS() {
        if (ttsInstance != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    ttsInstance.stop();
                }
            });
        }
    }

    // 3. Android Native SpeechRecognizer Bridge (Runs on Main UI Looper)
    public static void startListening(final Activity activity, final String languageTag) {
        lastSpeechStatus = "STARTING";
        lastSpeechError = "";
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
                        lastSpeechStatus = "ERROR";
                        lastSpeechError = "Speech recognition service is not available on this device.";
                        return;
                    }
                    if (speechRecognizer != null) {
                        speechRecognizer.destroy();
                    }
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(activity);
                    speechRecognizer.setRecognitionListener(new RecognitionListener() {
                        @Override public void onReadyForSpeech(Bundle params) { lastSpeechStatus = "LISTENING"; }
                        @Override public void onBeginningOfSpeech() { lastSpeechStatus = "SPEAKING"; }
                        @Override public void onRmsChanged(float rmsdB) {}
                        @Override public void onBufferReceived(byte[] buffer) {}
                        @Override public void onEndOfSpeech() { lastSpeechStatus = "PROCESSING"; }
                        @Override public void onError(int error) {
                            lastSpeechStatus = "ERROR";
                            lastSpeechError = "SpeechRecognizer Error Code: " + error;
                        }
                        @Override public void onResults(Bundle results) {
                            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                            if (matches != null && !matches.isEmpty()) {
                                lastRecognizedText = matches.get(0);
                            }
                            lastSpeechStatus = "DONE";
                        }
                        @Override public void onPartialResults(Bundle partialResults) {
                            ArrayList<String> partials = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                            if (partials != null && !partials.isEmpty()) {
                                lastRecognizedText = partials.get(0);
                            }
                        }
                        @Override public void onEvent(int eventType, Bundle params) {}
                    });

                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag);
                    speechRecognizer.startListening(intent);
                } catch (Exception e) {
                    lastSpeechStatus = "ERROR";
                    lastSpeechError = e.getMessage();
                }
            }
        });
    }

    public static void stopListening() {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if (speechRecognizer != null) {
                    speechRecognizer.stopListening();
                    lastSpeechStatus = "IDLE";
                }
            }
        });
    }

    public static String getSpeechStateJson() {
        try {
            JSONObject obj = new JSONObject();
            obj.put("status", lastSpeechStatus);
            obj.put("text", lastRecognizedText);
            obj.put("error", lastSpeechError);
            return obj.toString();
        } catch (Exception e) {
            return "{\"status\":\"ERROR\",\"text\":\"\",\"error\":\"JSON error\"}";
        }
    }

    // 4. Overlay Permission & Floating Window Trigger
    public static boolean canDrawOverlays(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(context);
        }
        return true;
    }

    public static void openOverlaySettings(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        }
    }

    // 5. Installed Launchable Apps Discovery
    public static String getInstalledAppsJson(Context context) {
        JSONArray array = new JSONArray();
        try {
            PackageManager pm = context.getPackageManager();
            List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo appInfo : packages) {
                Intent launchIntent = pm.getLaunchIntentForPackage(appInfo.packageName);
                if (launchIntent != null) {
                    JSONObject item = new JSONObject();
                    item.put("name", pm.getApplicationLabel(appInfo).toString());
                    item.put("package", appInfo.packageName);
                    array.put(item);
                }
            }
        } catch (Exception ignored) {}
        return array.toString();
    }

    public static boolean launchPackage(Context context, String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launchIntent);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }
}