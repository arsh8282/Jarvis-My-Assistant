package org.jarvis.bridge;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

public class JarvisScreenCaptureHelper {
    public static final int REQUEST_MEDIA_PROJECTION = 9482;

    private static MediaProjectionManager projectionManager;
    private static MediaProjection mediaProjection;
    private static VirtualDisplay virtualDisplay;
    private static ImageReader imageReader;
    private static int screenDensity;
    private static int captureWidth = 720;
    private static int captureHeight = 1280;
    private static boolean permissionPending = false;
    private static String lastCaptureError = "";

    private static final MediaProjection.Callback PROJECTION_CALLBACK = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            super.onStop();
            stopProjection();
        }
    };

    /**
     * Launches the Android system MediaProjection consent dialog.
     * The Python side receives the result via android.activity.bind(on_activity_result=...)
     * and passes (resultCode, dataIntent) to onActivityResult().
     */
    public static boolean requestCapturePermission(final Activity activity) {
        try {
            projectionManager = (MediaProjectionManager) activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if (projectionManager == null) {
                lastCaptureError = "MediaProjectionManager unavailable on this device.";
                return false;
            }
            DisplayMetrics metrics = new DisplayMetrics();
            WindowManager wm = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null && wm.getDefaultDisplay() != null) {
                wm.getDefaultDisplay().getRealMetrics(metrics);
                screenDensity = metrics.densityDpi;
                // Scale to 720p width to save RAM and Gemini upload bandwidth
                float ratio = (float) metrics.heightPixels / (float) Math.max(1, metrics.widthPixels);
                captureWidth = 720;
                captureHeight = Math.max(720, (int) (720 * ratio));
            }
            permissionPending = true;
            Intent captureIntent = projectionManager.createScreenCaptureIntent();
            activity.startActivityForResult(captureIntent, REQUEST_MEDIA_PROJECTION);
            return true;
        } catch (Exception e) {
            lastCaptureError = "Failed requesting MediaProjection: " + e.getMessage();
            permissionPending = false;
            return false;
        }
    }

    /**
     * Called from Python's android.activity on_activity_result callback.
     */
    public static boolean onActivityResult(final Context context, final int requestCode, final int resultCode, final Intent data) {
        if (requestCode != REQUEST_MEDIA_PROJECTION) return false;
        permissionPending = false;

        if (resultCode != Activity.RESULT_OK || data == null) {
            lastCaptureError = "User denied screen capture authorization.";
            return false;
        }

        try {
            if (projectionManager == null) {
                projectionManager = (MediaProjectionManager) context.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            }
            stopProjection();
            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            if (mediaProjection == null) {
                lastCaptureError = "Could not initialize MediaProjection token.";
                return false;
            }

            // Mandatory on Android 14 (API 34) and Android 15 (API 35) before createVirtualDisplay
            mediaProjection.registerCallback(PROJECTION_CALLBACK, new Handler(Looper.getMainLooper()));

            imageReader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2);
            virtualDisplay = mediaProjection.createVirtualDisplay(
                    "JarvisScreenVisionDisplay",
                    captureWidth,
                    captureHeight,
                    screenDensity > 0 ? screenDensity : 320,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),
                    null,
                    null
            );
            lastCaptureError = "";
            return true;
        } catch (SecurityException se) {
            lastCaptureError = "Android 14/15 SecurityException: MediaProjection requires active foreground state (" + se.getMessage() + ")";
            stopProjection();
            return false;
        } catch (Exception e) {
            lastCaptureError = "Error starting VirtualDisplay: " + e.getMessage();
            stopProjection();
            return false;
        }
    }

    public static boolean isProjectionActive() {
        return mediaProjection != null && virtualDisplay != null && imageReader != null;
    }

    public static String captureFrameToFile(String outputFilePath) {
        if (!isProjectionActive()) {
            return "";
        }
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) {
                lastCaptureError = "No new screen frame ready yet; try again in a moment.";
                return "";
            }
            int width = image.getWidth();
            int height = image.getHeight();
            final Image.Plane[] planes = image.getPlanes();
            final ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * width;

            Bitmap bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
            );
            bitmap.copyPixelsFromBuffer(buffer);
            Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, width, height);
            bitmap.recycle();

            File outFile = new File(outputFilePath);
            File parent = outFile.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            try (FileOutputStream fos = new FileOutputStream(outFile)) {
                cropped.compress(Bitmap.CompressFormat.JPEG, 82, fos);
                fos.flush();
            }
            cropped.recycle();
            return outFile.getAbsolutePath();
        } catch (Exception e) {
            lastCaptureError = "Frame capture error: " + e.getMessage();
            return "";
        } finally {
            if (image != null) {
                try {
                    image.close();
                } catch (Exception ignored) {}
            }
        }
    }

    public static void stopProjection() {
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
            if (imageReader != null) {
                imageReader.close();
                imageReader = null;
            }
            if (mediaProjection != null) {
                mediaProjection.unregisterCallback(PROJECTION_CALLBACK);
                mediaProjection.stop();
                mediaProjection = null;
            }
        } catch (Exception ignored) {}
    }

    public static String getLastError() {
        return lastCaptureError;
    }
}