from typing import Tuple, Optional
from jarvis.config import ConfigManager
from jarvis.model_manager import ModelManager
from jarvis.screen_capture import ScreenCaptureManager


class ScreenVisionCoordinator:
    """Coordinates privacy checks, model vision compatibility, and frame preparation."""

    def __init__(self, config: ConfigManager, model_manager: ModelManager, capture_mgr: ScreenCaptureManager):
        self.config = config
        self.model_manager = model_manager
        self.capture_mgr = capture_mgr

    def is_enabled(self) -> bool:
        return bool(self.config.get("screen_vision_enabled", False))

    def set_enabled(self, enabled: bool) -> None:
        self.config.set("screen_vision_enabled", bool(enabled))
        self.capture_mgr.authorize_session(bool(enabled))
        if not enabled:
            self.capture_mgr.clear_temporary_captures()

    def prepare_screen_analysis(self, custom_image_path: Optional[str] = None) -> Tuple[Optional[bytes], str]:
        if not self.is_enabled():
            return None, "Screen Vision is disabled. Enable 'Screen Vision' in Settings first."

        ok, msg = self.model_manager.validate_vision_support()
        if not ok:
            return None, msg

        if custom_image_path:
            return self.capture_mgr.compress_image_file(custom_image_path)

        return self.capture_mgr.capture_current_frame()