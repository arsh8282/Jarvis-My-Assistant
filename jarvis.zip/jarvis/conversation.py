import uuid
from typing import List, Dict
from jarvis.database import ConversationDatabase
from jarvis.config import ConfigManager


class ConversationManager:
    """Manages active chat context, history trimming, and optional SQLite persistence."""

    def __init__(self, db: ConversationDatabase, config: ConfigManager):
        self.db = db
        self.config = config
        self.session_id = "default_session"
        self.history: List[Dict[str, str]] = []
        self._load_initial_history()

    def _load_initial_history(self) -> None:
        if self.config.get("save_history_locally", True):
            limit = int(self.config.get("max_history_messages", 16))
            saved = self.db.get_recent_messages(self.session_id, limit=limit)
            self.history = [{"role": m["role"], "content": m["content"]} for m in saved]

    def add_turn(self, user_text: str, assistant_text: str) -> None:
        self.history.append({"role": "user", "content": user_text})
        self.history.append({"role": "model", "content": assistant_text})
        self._trim()
        if self.config.get("save_history_locally", True):
            self.db.add_message(self.session_id, "user", user_text)
            self.db.add_message(self.session_id, "model", assistant_text)

    def get_trimmed_context(self) -> List[Dict[str, str]]:
        self._trim()
        return list(self.history)

    def _trim(self) -> None:
        max_msgs = max(2, int(self.config.get("max_history_messages", 16)))
        if len(self.history) > max_msgs:
            self.history = self.history[-max_msgs:]

    def start_new_session(self) -> None:
        self.session_id = f"session_{uuid.uuid4().hex[:8]}"
        self.history.clear()

    def clear_all_history(self) -> None:
        self.history.clear()
        self.db.clear_all_messages()