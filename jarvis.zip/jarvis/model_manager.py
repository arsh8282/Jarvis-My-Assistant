from typing import List, Dict, Any, Optional, Tuple
from jarvis.gemini_client import GeminiClient
from jarvis.database import ConversationDatabase
from jarvis.config import ConfigManager


class ModelManager:
    """Handles dynamic model discovery, capability checks, caching, and selection."""

    def __init__(self, client: GeminiClient, db: ConversationDatabase, config: ConfigManager):
        self.client = client
        self.db = db
        self.config = config
        self.available_models: List[Dict[str, Any]] = self.db.load_models_cache()

    def refresh_models(self, api_key: str) -> List[Dict[str, Any]]:
        models = self.client.list_models(api_key)
        self.available_models = models
        self.db.save_models_cache(models)

        current = self.config.get("selected_model", "")
        names = [m["name"] for m in models]
        if not current or current not in names:
            # Prefer a modern flash or pro model if present
            preferred = next((n for n in names if "flash" in n.lower()), names[0])
            self.config.set("selected_model", preferred)
        return models

    def get_models(self) -> List[Dict[str, Any]]:
        return self.available_models

    def select_model(self, model_name: str) -> bool:
        clean = model_name.replace("models/", "").strip()
        for m in self.available_models:
            if m["name"] == clean:
                self.config.set("selected_model", clean)
                return True
        return False

    def get_selected_model_info(self) -> Optional[Dict[str, Any]]:
        selected = self.config.get("selected_model", "")
        for m in self.available_models:
            if m["name"] == selected:
                return m
        return None

    def validate_vision_support(self) -> Tuple[bool, str]:
        info = self.get_selected_model_info()
        if not info:
            return False, "No model selected. Please refresh and select a Gemini model first."
        if not info.get("supports_vision", False):
            compatible = [m["name"] for m in self.available_models if m.get("supports_vision")]
            suggestion = f" Compatible models: {', '.join(compatible[:3])}" if compatible else ""
            return False, f"Model '{info['name']}' does not support image analysis.{suggestion}"
        return True, "Vision supported."