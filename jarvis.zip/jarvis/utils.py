import re
import logging
from typing import List, Tuple

SECRET_PATTERNS = [
    re.compile(r"AIza[0-9A-Za-z\-_]{20,}"),
    re.compile(r"(x-goog-api-key['\"\s:=]+)([0-9A-Za-z\-_]+)", re.IGNORECASE),
]


def redact_secrets(text: str) -> str:
    """Removes Gemini API keys or secret tokens from logs and error strings."""
    if not text:
        return ""
    cleaned = str(text)
    cleaned = SECRET_PATTERNS[0].sub("AIza[REDACTED_KEY]", cleaned)
    cleaned = SECRET_PATTERNS[1].sub(r"\1[REDACTED]", cleaned)
    return cleaned


class SafeLogger:
    """Logger wrapper that guarantees API keys are never written to logcat."""

    def __init__(self, name: str = "JARVIS"):
        self.logger = logging.getLogger(name)
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter("[%(levelname)s] %(name)s: %(message)s")
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        self.recent_logs: List[str] = []

    def _record(self, level: str, msg: str):
        safe_msg = redact_secrets(msg)
        entry = f"[{level}] {safe_msg}"
        self.recent_logs.append(entry)
        if len(self.recent_logs) > 100:
            self.recent_logs.pop(0)
        return safe_msg

    def info(self, msg: str):
        self.logger.info(self._record("INFO", msg))

    def warning(self, msg: str):
        self.logger.warning(self._record("WARN", msg))

    def error(self, msg: str):
        self.logger.error(self._record("ERROR", msg))

    def get_diagnostics(self) -> str:
        return "\n".join(self.recent_logs[-40:])


logger = SafeLogger()


def extract_code_blocks(markdown_text: str) -> List[Tuple[str, str]]:
    """Returns a list of (language, code) tuples extracted from markdown fences."""
    if not markdown_text:
        return []
    pattern = re.compile(r"```([a-zA-Z0-9_-]*)\n(.*?)```", re.DOTALL)
    matches = pattern.findall(markdown_text)
    return [(lang.strip() or "code", code.strip("\n")) for lang, code in matches]


def summarize_code_for_speech(markdown_text: str) -> str:
    """
    Converts raw markdown with Smali/Java/Python blocks into natural spoken summaries
    so TTS explains instructions instead of reading raw symbols aloud.
    """
    if not markdown_text:
        return ""

    def _replace_block(match):
        lang = (match.group(1) or "code").strip().lower()
        code = match.group(2)
        spoken_notes = []
        if ".locals" in code:
            m = re.search(r"\.locals\s+(\d+)", code)
            if m:
                spoken_notes.append(f"This method reserves {m.group(1)} local registers.")
        if "if-eqz" in code:
            spoken_notes.append("It includes an if-equal-to-zero conditional branch instruction.")
        elif "if-nez" in code:
            spoken_notes.append("It includes an if-not-equal-to-zero conditional branch instruction.")
        if not spoken_notes:
            spoken_notes.append(f"A {lang} code block is shown on screen and ready to copy.")
        return " " + " ".join(spoken_notes) + " "

    processed = re.sub(r"```([a-zA-Z0-9_-]*)\n(.*?)```", _replace_block, markdown_text, flags=re.DOTALL)
    # Remove markdown formatting symbols
    processed = re.sub(r"[#*`_~>]", "", processed)
    return re.sub(r"\s+", " ", processed).strip()