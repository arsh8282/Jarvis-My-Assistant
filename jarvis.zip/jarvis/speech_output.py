from typing import List
from jarvis.config import ConfigManager
from jarvis.android_bridge import AndroidBridge
from jarvis.utils import summarize_code_for_speech


class SpeechOutputManager:
    """
    Controls Android TextToSpeech playback, chunking long responses,
    intelligently summarizing code blocks, and respecting the top-right speech toggle.
    """

    def __init__(self, bridge: AndroidBridge, config: ConfigManager):
        self.bridge = bridge
        self.config = config
        self._last_spoken_hash = None

    def is_auto_speech_enabled(self) -> bool:
        return bool(self.config.get("speech_auto_enabled", True))

    def set_auto_speech(self, enabled: bool) -> None:
        self.config.set("speech_auto_enabled", bool(enabled))
        if not enabled:
            self.stop()

    def speak_response(self, raw_markdown: str, manual_override: bool = False) -> bool:
        if not raw_markdown or not raw_markdown.strip():
            return False
        if not manual_override and not self.is_auto_speech_enabled():
            return False

        msg_hash = hash(raw_markdown)
        if not manual_override and msg_hash == self._last_spoken_hash:
            return False
        self._last_spoken_hash = msg_hash

        spoken_text = summarize_code_for_speech(raw_markdown)
        chunks = self._chunk_text(spoken_text, max_len=320)
        rate = float(self.config.get("speech_rate", 1.0))
        pitch = float(self.config.get("speech_pitch", 1.0))

        self.stop()
        for idx, chunk in enumerate(chunks):
            self.bridge.speak(chunk, rate=rate, pitch=pitch, flush=(idx == 0))
        return True

    def stop(self) -> None:
        self.bridge.stop_speaking()

    @staticmethod
    def _chunk_text(text: str, max_len: int = 320) -> List[str]:
        sentences = text.replace(". ", ".|").split("|")
        chunks: List[str] = []
        current = ""
        for s in sentences:
            if len(current) + len(s) + 1 <= max_len:
                current = f"{current} {s}".strip()
            else:
                if current:
                    chunks.append(current)
                current = s[:max_len]
        if current:
            chunks.append(current)
        return chunks or [text[:max_len]]