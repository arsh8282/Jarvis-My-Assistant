from kivy.utils import platform
from jarvis.utils import logger


class PermissionManager:
    """Handles runtime Android permissions for Microphone and Notifications."""

    def __init__(self, bridge):
        self.bridge = bridge
        self.is_android = (platform == "android")

    def ensure_microphone_permission(self, callback=None) -> bool:
        if not self.is_android:
            return True
        try:
            from android.permissions import check_permission, request_permissions, Permission
            if check_permission(Permission.RECORD_AUDIO):
                return True
            request_permissions([Permission.RECORD_AUDIO], callback)
            return False
        except Exception as e:
            logger.error(f"Microphone permission check failed: {e}")
            return False

    def request_notification_permission(self) -> None:
        if not self.is_android:
            return
        try:
            from android.permissions import request_permissions
            request_permissions(["android.permission.POST_NOTIFICATIONS"])
        except Exception:
            pass