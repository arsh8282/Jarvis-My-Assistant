import os
import base64
import hashlib
from jarvis.utils import logger


class SecureKeyStorage:
    """
    Stores the Gemini API key using Android's Hardware-Backed KeyStore (AES/GCM)
    via JarvisBridge when running on Android, with an obfuscated local fallback
    for desktop unit testing.
    """

    KEY_NAME = "gemini_api_key_v1"

    def __init__(self, storage_dir: str, android_bridge=None):
        self.storage_dir = storage_dir
        self.android_bridge = android_bridge
        self._fallback_path = os.path.join(storage_dir, ".sec_vault.dat")

    def save_api_key(self, api_key: str) -> bool:
        cleaned = (api_key or "").strip()
        if not cleaned:
            return False

        if self.android_bridge and self.android_bridge.is_android:
            ok = self.android_bridge.save_secret(self.KEY_NAME, cleaned)
            if ok:
                return True

        # Fallback for non-Android unit-test environments
        try:
            mask = hashlib.sha256(self.storage_dir.encode("utf-8")).digest()
            raw = cleaned.encode("utf-8")
            xored = bytes(b ^ mask[i % len(mask)] for i, b in enumerate(raw))
            with open(self._fallback_path, "wb") as f:
                f.write(base64.b64encode(xored))
            return True
        except Exception as e:
            logger.error(f"Secure storage write failed: {e}")
            return False

    def load_api_key(self) -> str:
        if self.android_bridge and self.android_bridge.is_android:
            secret = self.android_bridge.load_secret(self.KEY_NAME)
            if secret:
                return secret.strip()

        if not os.path.exists(self._fallback_path):
            return ""
        try:
            mask = hashlib.sha256(self.storage_dir.encode("utf-8")).digest()
            with open(self._fallback_path, "rb") as f:
                encoded = f.read()
            xored = base64.b64decode(encoded)
            raw = bytes(b ^ mask[i % len(mask)] for i, b in enumerate(xored))
            return raw.decode("utf-8").strip()
        except Exception as e:
            logger.error(f"Secure storage read failed: {e}")
            return ""

    def clear_api_key(self) -> None:
        if self.android_bridge and self.android_bridge.is_android:
            self.android_bridge.clear_secret(self.KEY_NAME)
        if os.path.exists(self._fallback_path):
            try:
                os.remove(self._fallback_path)
            except OSError:
                pass