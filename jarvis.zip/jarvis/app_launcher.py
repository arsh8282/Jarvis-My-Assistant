from typing import List, Dict, Tuple
from jarvis.android_bridge import AndroidBridge


class AppLauncher:
    """Searches and launches installed Android applications via PackageManager."""

    def __init__(self, bridge: AndroidBridge):
        self.bridge = bridge
        self.cached_apps: List[Dict[str, str]] = []

    def refresh_apps(self) -> List[Dict[str, str]]:
        self.cached_apps = self.bridge.get_installed_apps()
        self.cached_apps.sort(key=lambda x: x.get("name", "").lower())
        return self.cached_apps

    def search_apps(self, query: str) -> List[Dict[str, str]]:
        if not self.cached_apps:
            self.refresh_apps()
        q = (query or "").strip().lower()
        if not q:
            return self.cached_apps
        return [
            app
            for app in self.cached_apps
            if q in app.get("name", "").lower() or q in app.get("package", "").lower()
        ]

    def open_app_by_query(self, query: str) -> Tuple[bool, str]:
        matches = self.search_apps(query)
        if not matches:
            return False, f"No installed launchable app found matching '{query}'."
        target = matches[0]
        launched = self.bridge.launch_app(target["package"])
        if launched:
            return True, f"Launched {target['name']} ({target['package']})."
        return False, f"Found {target['name']}, but Android could not launch it (only simulated on desktop)."