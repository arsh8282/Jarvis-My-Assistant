import os
import sqlite3
import time
from typing import List, Dict, Any


class ConversationDatabase:
    """SQLite database for optional local conversation persistence and model metadata caching."""

    def __init__(self, storage_dir: str):
        os.makedirs(storage_dir, exist_ok=True)
        self.db_path = os.path.join(storage_dir, "jarvis_memory.db")
        self._init_db()

    def _connect(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS model_cache (
                    name TEXT PRIMARY KEY,
                    display_name TEXT,
                    supports_vision INTEGER,
                    raw_json TEXT,
                    updated_at REAL
                )
                """
            )
            conn.commit()

    def add_message(self, session_id: str, role: str, content: str) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO messages (session_id, role, content, timestamp) VALUES (?, ?, ?, ?)",
                (session_id, role, content, time.time()),
            )
            conn.commit()

    def get_recent_messages(self, session_id: str, limit: int = 20) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            cur = conn.execute(
                "SELECT role, content, timestamp FROM messages WHERE session_id = ? ORDER BY id DESC LIMIT ?",
                (session_id, limit),
            )
            rows = cur.fetchall()
        rows.reverse()
        return [{"role": r[0], "content": r[1], "timestamp": r[2]} for r in rows]

    def clear_all_messages(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM messages")
            conn.commit()

    def save_models_cache(self, models_list: List[Dict[str, Any]]) -> None:
        now = time.time()
        with self._connect() as conn:
            conn.execute("DELETE FROM model_cache")
            for m in models_list:
                conn.execute(
                    "INSERT INTO model_cache (name, display_name, supports_vision, raw_json, updated_at) VALUES (?, ?, ?, ?, ?)",
                    (
                        m["name"],
                        m.get("display_name", m["name"]),
                        1 if m.get("supports_vision") else 0,
                        m.get("description", ""),
                        now,
                    ),
                )
            conn.commit()

    def load_models_cache(self) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            cur = conn.execute("SELECT name, display_name, supports_vision, raw_json FROM model_cache")
            rows = cur.fetchall()
        return [
            {
                "name": r[0],
                "display_name": r[1],
                "supports_vision": bool(r[2]),
                "description": r[3],
                "supports_generate": True,
            }
            for r in rows
        ]

    def clear_models_cache(self) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM model_cache")
            conn.commit()