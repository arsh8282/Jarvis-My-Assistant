import os
import json
from typing import Any, Dict
from jarvis.utils import logger

DEFAULT_CONFIG: Dict[str, Any] = {
    "selected_model": "",
    "speech_auto_enabled": True,
    "speech_rate": 1.0,
    "speech_pitch": 1.0,
    "speech_language": "en-IN",
    "voice_mode": "push_to_talk",  # "push_to_talk" or "voice_conversation"
    "request_timeout": 35,
    "max_history_messages": 16,
    "save_history_locally": True,
    "screen_vision_enabled": False,
    "screen_capture_only_on_request": True,
    "floating_assistant_enabled": False,
    "modding_language": "Hinglish",
    "modding_verbosity": "Detailed",
}


class ConfigManager:
    """Manages non-sensitive persistent application settings in JSON."""

    def __init__(self, storage_dir: str):
        self.storage_dir = storage_dir
        os.makedirs(self.storage_dir, exist_ok=True)
        self.config_path = os.path.join(self.storage_dir, "jarvis_config.json")
        self.settings: Dict[str, Any] = dict(DEFAULT_CONFIG)
        self.load()

    def load(self) -> Dict[str, Any]:
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                if isinstance(loaded, dict):
                    for k, v in DEFAULT_CONFIG.items():
                        self.settings[k] = loaded.get(k, v)
            except Exception as e:
                logger.error(f"Failed loading config, using defaults: {e}")
        return self.settings

    def save(self) -> bool:
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Failed saving config: {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        return self.settings.get(key, DEFAULT_CONFIG.get(key, default))

    def set(self, key: str, value: Any) -> None:
        self.settings[key] = value
        self.save()

    def reset_defaults(self) -> None:
        self.settings = dict(DEFAULT_CONFIG)
        self.save()