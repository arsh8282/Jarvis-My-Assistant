import io
import os
from typing import Optional, Tuple
from PIL import Image
from kivy.core.window import Window
from jarvis.utils import logger


class ScreenCaptureManager:
    """
    Handles explicitly authorized screen capture using Android's MediaProjection API
    (via JarvisScreenCaptureHelper) when active, or Kivy's window buffer / attached
    screenshot file as a fallback.
    """

    def __init__(self, storage_dir: str, bridge=None):
        self.capture_dir = os.path.join(storage_dir, "temp_captures")
        os.makedirs(self.capture_dir, exist_ok=True)
        self.bridge = bridge
        self.session_authorized = False

    def authorize_session(self, granted: bool) -> None:
        self.session_authorized = bool(granted)
        if granted and self.bridge and self.bridge.is_android:
            if not self.bridge.is_media_projection_active():
                self.bridge.request_media_projection()
        elif not granted and self.bridge and self.bridge.is_android:
            self.bridge.stop_media_projection()

    def capture_current_frame(self, max_dimension: int = 1280) -> Tuple[Optional[bytes], str]:
        if not self.session_authorized:
            return None, "Screen Vision is disabled. Enable 'Screen Vision' in Settings first."

        # 1. Prefer native Android MediaProjection frame if active (captures full screen or selected app on Android 14/15)
        if self.bridge and self.bridge.is_android and self.bridge.is_media_projection_active():
            mp_target = os.path.join(self.capture_dir, "jarvis_mp_frame.jpg")
            saved_mp = self.bridge.capture_media_projection_frame(mp_target)
            if saved_mp and os.path.exists(saved_mp):
                return self.compress_image_file(saved_mp, max_dimension=max_dimension)

        # 2. Fallback to active Kivy Window buffer
        temp_path = os.path.join(self.capture_dir, "jarvis_screen_snap.png")
        try:
            Window.screenshot(name=temp_path)
            actual_file = None
            for fname in sorted(os.listdir(self.capture_dir), reverse=True):
                if fname.startswith("jarvis_screen_snap") and fname.endswith(".png"):
                    actual_file = os.path.join(self.capture_dir, fname)
                    break

            if not actual_file or not os.path.exists(actual_file):
                return None, "Could not capture frame. Grant MediaProjection permission or paste code directly."

            return self.compress_image_file(actual_file, max_dimension=max_dimension)
        except Exception as e:
            logger.error(f"Screen capture failed: {e}")
            return None, f"Capture failed: {e}"

    def compress_image_file(self, image_path: str, max_dimension: int = 1280) -> Tuple[Optional[bytes], str]:
        if not os.path.exists(image_path):
            return None, "Selected image file does not exist."
        try:
            with Image.open(image_path) as img:
                img = img.convert("RGB")
                img.thumbnail((max_dimension, max_dimension), Image.Resampling.LANCZOS)
                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=82, optimize=True)
                return buf.getvalue(), "OK"
        except Exception as e:
            logger.error(f"Image compression error: {e}")
            return None, f"Failed processing image: {e}"

    def clear_temporary_captures(self) -> int:
        removed = 0
        if os.path.exists(self.capture_dir):
            for fname in os.listdir(self.capture_dir):
                fpath = os.path.join(self.capture_dir, fname)
                try:
                    os.remove(fpath)
                    removed += 1
                except OSError:
                    pass
        return removed