import os  
import json  
from typing import Tuple  
from jarvis.utils import logger  
  
DEFAULT_SYSTEM_INSTRUCTIONS = (  
    "You are JARVIS, my personal AI assistant. Address me as Sir. "  
    "Explain technical topics in simple Hinglish unless I request another language. "  
    "Prioritize Android development, APK modding, Smali debugging, and accurate step-by-step explanations. "  
    "Analyze the actual code before suggesting changes. Identify exact lines when supported by evidence. "  
    "Explain what important Smali instructions mean using simple examples. "  
    "Keep answers clear, professional, friendly, and technically accurate. "  
    "Distinguish confirmed facts from assumptions. "  
    "Do not claim to have inspected files, screens, applications, or logs that you have not actually accessed. "  
    "Ask for missing code or context when necessary. "  
    "Respect my selected language, response style, and task-specific instructions."  
)  
  
  
class InstructionManager:  
    """Manages editable custom system instructions with validation and persistence."""  
  
    def __init__(self, storage_dir: str):  
        self.storage_dir = storage_dir  
        os.makedirs(self.storage_dir, exist_ok=True)  
        self.file_path = os.path.join(self.storage_dir, "system_instructions.json")  
        self._active_instructions = DEFAULT_SYSTEM_INSTRUCTIONS  
        self.load()  
  
    def load(self) -> str:  
        if os.path.exists(self.file_path):  
            try:  
                with open(self.file_path, "r", encoding="utf-8") as f:  
                    data = json.load(f)  
                text = (data.get("instructions") or "").strip()  
                if text:  
                    self._active_instructions = text  
            except Exception as e:  
                logger.error(f"Failed loading custom instructions: {e}")  
        return self._active_instructions  
  
    def get_active(self) -> str:  
        return self._active_instructions  
  
    def save_custom(self, new_text: str) -> Tuple[bool, str]:  
        cleaned = (new_text or "").strip()  
        if not cleaned:  
            return False, "Instructions cannot be empty. Use Restore Default if you want the standard persona."  
        self._active_instructions = cleaned  
        try:  
            with open(self.file_path, "w", encoding="utf-8") as f:  
                json.dump({"instructions": cleaned}, f, indent=2)  
            return True, "Custom instructions saved and active."  
        except Exception as e:  
            logger.error(f"Error saving instructions: {e}")  
            return False, "Failed to write instructions to storage."  
  
    def restore_default(self) -> str:  
        self._active_instructions = DEFAULT_SYSTEM_INSTRUCTIONS  
        try:  
            with open(self.file_path, "w", encoding="utf-8") as f:  
                json.dump({"instructions": DEFAULT_SYSTEM_INSTRUCTIONS}, f, indent=2)  
        except Exception as e:  
            logger.error(f"Error restoring default instructions: {e}")  
        return self._active_instructions  
  