import os  
import sys  
import threading  
import webbrowser  
  
# Ensure imports work cleanly whether launched from root or inside jarvis/  
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))  
PARENT_DIR = os.path.dirname(CURRENT_DIR)  
for p in (CURRENT_DIR, PARENT_DIR):  
    if p not in sys.path:  
        sys.path.insert(0, p)  
  
from kivy.app import App  
from kivy.clock import Clock  
from kivy.core.clipboard import Clipboard  
from kivy.lang import Builder  
from kivy.properties import BooleanProperty, ListProperty, StringProperty  
from kivy.uix.screenmanager import ScreenManager  
  
from jarvis.action_manager import ActionManager  
from jarvis.android_bridge import AndroidBridge  
from jarvis.app_launcher import AppLauncher  
from jarvis.config import ConfigManager  
from jarvis.conversation import ConversationManager  
from jarvis.database import ConversationDatabase  
from jarvis.floating_assistant import FloatingAssistantManager  
from jarvis.gemini_client import GeminiAPIError, GeminiClient  
from jarvis.instructions import InstructionManager  
from jarvis.model_manager import ModelManager  
from jarvis.permissions import PermissionManager  
from jarvis.screen_capture import ScreenCaptureManager  
from jarvis.screen_vision import ScreenVisionCoordinator  
from jarvis.security import SecureKeyStorage  
from jarvis.smali_assistant import SmaliAssistant  
from jarvis.speech_input import SpeechInputManager  
from jarvis.speech_output import SpeechOutputManager  
from jarvis.utils import extract_code_blocks, logger  
  
  
class RootScreenManager(ScreenManager):  
    pass  
  
  
class JarvisApp(App):  
    onboarding_status_text = StringProperty("Enter your Gemini API key to connect and discover models.")  
    available_model_names = ListProperty([])  
    selected_model_label = StringProperty("No model loaded")  
    current_model_short = StringProperty("No Model")  
    speech_auto_enabled = BooleanProperty(True)  
    screen_vision_enabled = BooleanProperty(False)  
    floating_enabled = BooleanProperty(False)  
    chat_status_banner = StringProperty("Ready.")  
    chat_transcript_markup = StringProperty(  
        "[b][color=00E5FF]JARVIS:[/color][/b] Welcome, Sir. Systems initialized. Select a model or ask a question.\n"  
    )  
    modding_output_text = StringProperty("Paste Smali code above and choose an analysis tool.")  
    custom_instructions_text = StringProperty("")  
    settings_feedback_text = StringProperty("")  
  
    def build(self):  
        self.title = "JARVIS AI"  
        storage_dir = self.user_data_dir  
        os.makedirs(storage_dir, exist_ok=True)  
  
        self.bridge = AndroidBridge()  
        self.permissions = PermissionManager(self.bridge)  
        self.config_mgr = ConfigManager(storage_dir)  
        self.security = SecureKeyStorage(storage_dir, self.bridge)  
        self.db = ConversationDatabase(storage_dir)  
        self.instructions_mgr = InstructionManager(storage_dir)  
        self.gemini = GeminiClient(timeout=int(self.config_mgr.get("request_timeout", 35)))  
        self.model_mgr = ModelManager(self.gemini, self.db, self.config_mgr)  
        self.conversation = ConversationManager(self.db, self.config_mgr)  
        self.speech_out = SpeechOutputManager(self.bridge, self.config_mgr)  
        self.speech_in = SpeechInputManager(self.bridge, self.permissions, self.config_mgr)  
        self.capture_mgr = ScreenCaptureManager(storage_dir)  
        self.screen_vision = ScreenVisionCoordinator(self.config_mgr, self.model_mgr, self.capture_mgr)  
        self.app_launcher = AppLauncher(self.bridge)  
        self.action_mgr = ActionManager(self.app_launcher)  
        self.smali = SmaliAssistant()  
        self.floating_mgr = FloatingAssistantManager(self.bridge, self.config_mgr, self._on_floating_command)  
  
        self.last_assistant_response = ""  
        self.speech_auto_enabled = self.speech_out.is_auto_speech_enabled()  
        self.screen_vision_enabled = self.screen_vision.is_enabled()  
        self.custom_instructions_text = self.instructions_mgr.get_active()  
  
        kv_path = os.path.join(CURRENT_DIR, "ui", "main.kv")  
        Builder.load_file(kv_path)  
        self.sm = RootScreenManager()  
  
        Clock.schedule_once(self._initialize_startup_flow, 0.2)  
        return self.sm  
  
    def _initialize_startup_flow(self, _dt):  
        saved_key = self.security.load_api_key()  
        cached_models = self.model_mgr.get_models()  
        selected = self.config_mgr.get("selected_model", "")  
  
        if cached_models:  
            self.available_model_names = [m["name"] for m in cached_models]  
        if selected:  
            self.selected_model_label = selected  
            self.current_model_short = selected  
  
        if saved_key and selected and cached_models:  
            self.sm.current = "chat"  
            self._rebuild_transcript_from_history()  
        else:  
            self.sm.current = "onboarding"  
  
    def save_key_and_fetch_models(self, raw_key: str):  
        key = (raw_key or "").strip() or self.security.load_api_key()  
        if not key:  
            self.onboarding_status_text = "Error: Please enter a valid Gemini API key first."  
            return  
  
        self.security.save_api_key(key)  
        self.onboarding_status_text = "Connecting to Gemini API and fetching models..."  
  
        def _worker():  
            try:  
                models = self.model_mgr.refresh_models(key)  
                names = [m["name"] for m in models]  
                selected = self.config_mgr.get("selected_model", names[0])  
  
                def _update_ui(_dt):  
                    self.available_model_names = names  
                    self.selected_model_label = selected  
                    self.current_model_short = selected  
                    self.onboarding_status_text = f"Connected! Found {len(names)} compatible Gemini models."  
  
                Clock.schedule_once(_update_ui, 0)  
            except GeminiAPIError as e:  
                Clock.schedule_once(  
                    lambda _dt: setattr(self, "onboarding_status_text", f"[{e.category}] {e.user_message}"), 0  
                )  
  
        threading.Thread(target=_worker, daemon=True).start()  
  
    def on_model_spinner_select(self, model_name: str):  
        if self.model_mgr.select_model(model_name):  
            self.selected_model_label = model_name  
            self.current_model_short = model_name  
  
    def complete_onboarding(self):  
        if not self.security.load_api_key():  
            self.onboarding_status_text = "Please save a valid Gemini API key before continuing."  
            return  
        if not self.config_mgr.get("selected_model"):  
            self.onboarding_status_text = "Please fetch and select a Gemini model first."  
            return  
        self.sm.current = "chat"  
  
    def open_gemini_docs(self):  
        webbrowser.open("https://ai.google.dev/gemini-api/docs/api-key")  
  
    def toggle_top_right_speech(self):  
        new_state = not self.speech_auto_enabled  
        self.speech_auto_enabled = new_state  
        self.speech_out.set_auto_speech(new_state)  
        self.chat_status_banner = "Auto-Speech ON" if new_state else "Auto-Speech OFF (Audio Stopped)"  
  
    def send_user_message(self, user_text: str, image_bytes: bytes = None):  
        cleaned = (user_text or "").strip()  
        if not cleaned:  
            return  
        if self.gemini.is_busy():  
            self.chat_status_banner = "JARVIS is currently processing a request..."  
            return  
  
        # Clear chat input box if on chat screen  
        try:  
            chat_screen = self.sm.get_screen("chat")  
            chat_screen.ids.chat_input.text = ""  
        except Exception:  
            pass  
  
        self._append_chat_bubble("You", cleaned, color_hex="2979FF")  
  
        # Check for direct local app launch command  
        action = self.action_mgr.detect_and_prepare_action(cleaned)  
        if action and not action.get("requires_confirmation"):  
            ok, msg = self.action_mgr.execute_action(action)  
            self._append_chat_bubble("JARVIS", msg, color_hex="00E5FF")  
            self.speech_out.speak_response(msg)  
            return  
  
        api_key = self.security.load_api_key()  
        model_name = self.config_mgr.get("selected_model", "")  
        sys_inst = self.instructions_mgr.get_active()  
        history = self.conversation.get_trimmed_context()  
  
        self.chat_status_banner = f"Querying {model_name}..."  
  
        def _worker():  
            try:  
                reply = self.gemini.generate_response(  
                    api_key=api_key,  
                    model_name=model_name,  
                    prompt_text=cleaned,  
                    system_instruction=sys_inst,  
                    history=history,  
                    image_bytes=image_bytes,  
                )  
  
                def _on_ok(_dt):  
                    self.last_assistant_response = reply  
                    self.conversation.add_turn(cleaned, reply)  
                    self._append_chat_bubble("JARVIS", reply, color_hex="00E5FF")  
                    self.chat_status_banner = "Response complete."  
                    self.speech_out.speak_response(reply, manual_override=False)  
  
                Clock.schedule_once(_on_ok, 0)  
            except GeminiAPIError as e:  
                def _on_err(_dt):  
                    err_txt = f"Error [{e.category}]: {e.user_message}"  
                    self._append_chat_bubble("System", err_txt, color_hex="FF5252")  
                    self.chat_status_banner = f"Failed: {e.category}"  
  
                Clock.schedule_once(_on_err, 0)  
  
        threading.Thread(target=_worker, daemon=True).start()  
  
    def _append_chat_bubble(self, sender: str, text: str, color_hex: str = "00E5FF"):  
        safe = text.replace("[", "&bl;").replace("]", "&br;")  
        self.chat_transcript_markup += f"\n[b][color={color_hex}]{sender}:[/color][/b]\n{safe}\n"  
  
    def _rebuild_transcript_from_history(self):  
        lines = ["[b][color=00E5FF]JARVIS:[/color][/b] Welcome back, Sir. Ready for instructions.\n"]  
        for item in self.conversation.get_trimmed_context():  
            role = "You" if item["role"] == "user" else "JARVIS"  
            col = "2979FF" if role == "You" else "00E5FF"  
            safe = item["content"].replace("[", "&bl;").replace("]", "&br;")  
            lines.append(f"\n[b][color={col}]{role}:[/color][/b]\n{safe}\n")  
        self.chat_transcript_markup = "".join(lines)  
  
    def speak_last_response_manual(self):  
        if self.last_assistant_response:  
            self.speech_out.speak_response(self.last_assistant_response, manual_override=True)  
            self.chat_status_banner = "Speaking last response..."  
  
    def stop_all_speech(self):  
        self.speech_out.stop()  
        self.chat_status_banner = "Audio playback stopped."  
  
    def copy_last_response(self):  
        if self.last_assistant_response:  
            Clipboard.copy(self.last_assistant_response)  
            self.chat_status_banner = "Copied full response to clipboard."  
  
    def copy_last_code_block(self):  
        blocks = extract_code_blocks(self.last_assistant_response)  
        if blocks:  
            Clipboard.copy(blocks[0][1])  
            self.chat_status_banner = f"Copied {blocks[0][0]} code block to clipboard."  
        else:  
            self.chat_status_banner = "No code block found in last response."  
  
    def cancel_current_request(self):  
        self.gemini.cancel_active_request()  
        self.chat_status_banner = "Cancelled active request."  
  
    def clear_conversation_prompt(self):  
        self.conversation.clear_all_history()  
        self.last_assistant_response = ""  
        self.chat_transcript_markup = "[b][color=00E5FF]JARVIS:[/color][/b] Conversation history cleared, Sir.\n"  
        self.chat_status_banner = "Conversation reset."  
  
    def trigger_voice_input(self):  
        self.chat_status_banner = "Listening... Speak now."  
  
        def _on_partial(text):  
            self.chat_status_banner = f"Hearing: {text}"  
  
        def _on_final(text):  
            self.chat_status_banner = "Voice recognized."  
            if not text:  
                return  
            mode = self.config_mgr.get("voice_mode", "push_to_talk")  
            if mode == "voice_conversation":  
                self.send_user_message(text)  
            else:  
                chat_screen = self.sm.get_screen("chat")  
                chat_screen.ids.chat_input.text = text  
  
        def _on_err(err_msg):  
            self.chat_status_banner = err_msg  
  
        self.speech_in.start_listening(_on_partial, _on_final, _on_err)  
  
    def trigger_screen_analysis(self, question: str):  
        q = (question or "").strip() or "Sirf is screen ko explain karo aur agar koi code/error hai to batao."  
        img_bytes, status_msg = self.screen_vision.prepare_screen_analysis()  
        if not img_bytes:  
            self._append_chat_bubble("System", status_msg, color_hex="FF5252")  
            self.chat_status_banner = "Screen capture blocked or disabled."  
            return  
        self.send_user_message(f"[Screen Vision Analysis] {q}", image_bytes=img_bytes)  
  
    def run_static_smali_check(self, smali_code: str):  
        self.modding_output_text = self.smali.format_local_static_report(smali_code)  
  
    def run_smali_diff(self, orig: str, mod: str):  
        self.modding_output_text = self.smali.compare_smali_versions(orig, mod)  
  
    def run_ai_smali_debug(self, smali_code: str, question: str):  
        if not smali_code or not smali_code.strip():  
            self.modding_output_text = "Please paste Smali bytecode first."  
            return  
        prompt = self.smali.build_debugging_prompt(  
            smali_code, question, language=self.config_mgr.get("modding_language", "Hinglish")  
        )  
        self.modding_output_text = "Analyzing Smali registers and execution flow with Gemini..."  
        api_key = self.security.load_api_key()  
        model_name = self.config_mgr.get("selected_model", "")  
        sys_inst = self.instructions_mgr.get_active()  
  
        def _worker():  
            try:  
                ans = self.gemini.generate_response(api_key, model_name, prompt, system_instruction=sys_inst)  
                Clock.schedule_once(lambda _dt: setattr(self, "modding_output_text", ans), 0)  
            except GeminiAPIError as e:  
                Clock.schedule_once(  
                    lambda _dt: setattr(self, "modding_output_text", f"[{e.category}] {e.user_message}"), 0  
                )  
  
        threading.Thread(target=_worker, daemon=True).start()  
  
    def copy_modding_output(self):  
        Clipboard.copy(self.modding_output_text)  
  
    def save_custom_instructions(self, text: str):  
        ok, msg = self.instructions_mgr.save_custom(text)  
        if ok:  
            self.custom_instructions_text = self.instructions_mgr.get_active()  
        self.settings_feedback_text = msg  
  
    def restore_default_instructions(self):  
        self.custom_instructions_text = self.instructions_mgr.restore_default()  
        self.settings_feedback_text = "Default JARVIS instructions restored."  
  
    def toggle_screen_vision(self):  
        new_val = not self.screen_vision_enabled  
        self.screen_vision_enabled = new_val  
        self.screen_vision.set_enabled(new_val)  
        self.settings_feedback_text = (  
            "Screen Vision Authorized (Frames sent to Gemini only when you tap Analyze Screen)."  
            if new_val  
            else "Screen Vision Disabled & temp captures cleared."  
        )  
  
    def toggle_floating_assistant(self):  
        if not self.floating_enabled:  
            ok, msg = self.floating_mgr.enable_floating_mode()  
            self.floating_enabled = ok  
            self.settings_feedback_text = msg  
        else:  
            self.floating_mgr.disable_floating_mode()  
            self.floating_enabled = False  
            self.settings_feedback_text = "Floating assistant closed."  
  
    def _on_floating_command(self, cmd: str):  
        if cmd == "VOICE_TRIGGER":  
            self.trigger_voice_input()  
        elif cmd == "SCREEN_VISION":  
            self.trigger_screen_analysis("Analyze current screen from floating assistant.")  
  
    def search_and_launch_app(self, query: str):  
        ok, msg = self.app_launcher.open_app_by_query(query)  
        self.settings_feedback_text = msg  
  
    def delete_saved_api_key(self):  
        self.security.clear_api_key()  
        self.settings_feedback_text = "Saved Gemini API key removed from device storage."  
  
    def purge_temp_captures(self):  
        count = self.capture_mgr.clear_temporary_captures()  
        self.settings_feedback_text = f"Purged {count} temporary screen capture file(s)."  
  
  
if __name__ == "__main__":  
    JarvisApp().run()  
  