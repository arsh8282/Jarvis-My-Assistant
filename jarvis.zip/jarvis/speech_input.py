from kivy.clock import Clock
from jarvis.android_bridge import AndroidBridge
from jarvis.permissions import PermissionManager
from jarvis.config import ConfigManager


class SpeechInputManager:
    """Manages push-to-talk and voice conversation speech recognition polling."""

    def __init__(self, bridge: AndroidBridge, permissions: PermissionManager, config: ConfigManager):
        self.bridge = bridge
        self.permissions = permissions
        self.config = config
        self._poll_event = None
        self.is_listening = False

    def start_listening(self, on_partial, on_final, on_error) -> None:
        if not self.permissions.ensure_microphone_permission():
            on_error("Microphone permission requested. Please grant permission and tap Mic again.")
            return

        lang = self.config.get("speech_language", "en-IN")
        started = self.bridge.start_speech_recognition(language=lang)
        if not started:
            on_error("Speech recognition is only available on an Android device with speech services installed.")
            return

        self.is_listening = True
        if self._poll_event:
            self._poll_event.cancel()

        def _poll_state(_dt):
            state = self.bridge.get_speech_state()
            status = state.get("status", "IDLE")
            text = state.get("text", "")
            err = state.get("error", "")

            if status in ("LISTENING", "SPEAKING", "PROCESSING") and text:
                on_partial(text)
            elif status == "DONE":
                self.is_listening = False
                if self._poll_event:
                    self._poll_event.cancel()
                on_final(text)
            elif status == "ERROR":
                self.is_listening = False
                if self._poll_event:
                    self._poll_event.cancel()
                on_error(err or "Speech recognition failed or timed out.")

        self._poll_event = Clock.schedule_interval(_poll_state, 0.25)

    def cancel_listening(self) -> None:
        self.is_listening = False
        if self._poll_event:
            self._poll_event.cancel()
        self.bridge.stop_speech_recognition()