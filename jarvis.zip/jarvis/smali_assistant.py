import re
import difflib
from typing import Dict, Any, List

SMALI_BRANCH_OPCODES = {
    "if-eq": "Branches if register A equals register B (A == B)",
    "if-ne": "Branches if register A does NOT equal register B (A != B)",
    "if-lt": "Branches if register A is less than register B (A < B)",
    "if-ge": "Branches if register A is greater than or equal to register B (A >= B)",
    "if-gt": "Branches if register A is greater than register B (A > B)",
    "if-le": "Branches if register A is less than or equal to register B (A <= B)",
    "if-eqz": "Branches to label if register equals 0 / false / null (reg == 0)",
    "if-nez": "Branches to label if register does NOT equal 0 / true / non-null (reg != 0)",
    "if-ltz": "Branches if register is less than 0 (reg < 0)",
    "if-gez": "Branches if register is greater than or equal to 0 (reg >= 0)",
    "if-gtz": "Branches if register is greater than 0 (reg > 0)",
    "if-lez": "Branches if register is less than or equal to 0 (reg <= 0)",
}


class SmaliAssistant:
    """
    Static analyzer and prompt builder for Smali bytecode, register validation,
    conditional branch tracing, and code comparison.
    """

    def inspect_registers_and_branches(self, smali_code: str) -> Dict[str, Any]:
        lines = (smali_code or "").splitlines()
        locals_count = None
        registers_count = None
        used_locals = set()
        used_params = set()
        defined_labels = set()
        branches: List[Dict[str, Any]] = []
        assignments: Dict[str, List[str]] = {}
        issues: List[str] = []

        for idx, raw_line in enumerate(lines, start=1):
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue

            if line.startswith(".locals"):
                m = re.match(r"\.locals\s+(\d+)", line)
                if m:
                    locals_count = int(m.group(1))
            elif line.startswith(".registers"):
                m = re.match(r"\.registers\s+(\d+)", line)
                if m:
                    registers_count = int(m.group(1))

            if line.startswith(":"):
                label_name = line.split()[0]
                defined_labels.add(label_name)

            for reg_match in re.findall(r"\b([vp]\d+)\b", line):
                if reg_match.startswith("v"):
                    used_locals.add(int(reg_match[1:]))
                elif reg_match.startswith("p"):
                    used_params.add(int(reg_match[1:]))

            # Track constant assignments
            const_match = re.match(r"(const(?:/4|/16|/high16|-wide|-string)?)\s+([vp]\d+),\s*(.+)", line)
            if const_match:
                reg = const_match.group(2)
                val = const_match.group(3)
                assignments.setdefault(reg, []).append(f"Line {idx}: {reg} = {val} ({line})")

            # Track conditional branches
            parts = line.split()
            opcode = parts[0] if parts else ""
            if opcode in SMALI_BRANCH_OPCODES:
                target_label = parts[-1] if parts[-1].startswith(":") else ""
                regs_in_op = re.findall(r"\b([vp]\d+)\b", line)
                branches.append(
                    {
                        "line_number": idx,
                        "instruction": line,
                        "opcode": opcode,
                        "meaning": SMALI_BRANCH_OPCODES[opcode],
                        "registers": regs_in_op,
                        "target": target_label,
                    }
                )

        # Check register bounds against .locals
        if locals_count is not None and used_locals:
            max_v = max(used_locals)
            if max_v >= locals_count:
                issues.append(
                    f"Register v{max_v} is used, but '.locals {locals_count}' only allocates v0..v{max(0, locals_count - 1)}. "
                    f"This will trigger a Dalvik/ART VerifyError at runtime."
                )

        # Check missing branch targets inside snippet
        for br in branches:
            target = br["target"]
            if target and defined_labels and target not in defined_labels:
                issues.append(
                    f"Line {br['line_number']}: Branch target '{target}' is not defined in the provided snippet."
                )

        return {
            "locals_declared": locals_count,
            "registers_declared": registers_count,
            "local_registers_used": sorted(f"v{i}" for i in used_locals),
            "param_registers_used": sorted(f"p{i}" for i in used_params),
            "defined_labels": sorted(defined_labels),
            "branches": branches,
            "assignments": assignments,
            "issues": issues,
        }

    def format_local_static_report(self, smali_code: str) -> str:
        if not smali_code or not smali_code.strip():
            return "Please paste a Smali snippet first."

        analysis = self.inspect_registers_and_branches(smali_code)
        out = ["### Static Smali Pre-Analysis"]
        out.append(f"- Declared `.locals`: {analysis['locals_declared']}")
        out.append(f"- Local Registers Used: {', '.join(analysis['local_registers_used']) or 'None'}")
        out.append(f"- Parameter Registers Used: {', '.join(analysis['param_registers_used']) or 'None'}")

        if analysis["assignments"]:
            out.append("\n**Register Constant Assignments Detected:**")
            for reg, hist in analysis["assignments"].items():
                for entry in hist:
                    out.append(f"  * {entry}")

        if analysis["branches"]:
            out.append("\n**Conditional Branches Found:**")
            for b in analysis["branches"]:
                out.append(
                    f"  * Line {b['line_number']}: `{b['instruction']}` -> {b['meaning']} (Target: `{b['target']}`)"
                )
        else:
            out.append("\n- No conditional `if-*` branches found in this snippet.")

        if analysis["issues"]:
            out.append("\n**Verifier / Control-Flow Warnings:**")
            for iss in analysis["issues"]:
                out.append(f"  * WARNING: {iss}")

        return "\n".join(out)

    def compare_smali_versions(self, original: str, modified: str) -> str:
        orig_lines = (original or "").splitlines()
        mod_lines = (modified or "").splitlines()
        diff = list(difflib.unified_diff(orig_lines, mod_lines, fromfile="Original.smali", tofile="Modified.smali", lineterm=""))
        if not diff:
            return "No differences found between Original and Modified Smali snippets."

        mod_analysis = self.inspect_registers_and_branches(modified)
        report = ["### Smali Diff & Verification Summary", "```diff"]
        report.extend(diff)
        report.append("```")
        if mod_analysis["issues"]:
            report.append("\n**Potential Issues in Modified Code:**")
            for issue in mod_analysis["issues"]:
                report.append(f"- {issue}")
        else:
            report.append("\n- Register bounds and local branch targets in Modified snippet passed basic static checks.")
        return "\n".join(report)

    def build_debugging_prompt(self, smali_code: str, user_question: str, language: str = "Hinglish") -> str:
        static_report = self.format_local_static_report(smali_code)
        return (
            f"Analyze the following Smali code and answer the user's question in {language}.\n"
            f"Follow the strict 8-part Smali debugging structure when debugging a logic/branch issue:\n"
            f"1. Problem\n2. Exact line\n3. Simple meaning\n4. Execution flow\n"
            f"5. Root cause\n6. Correction\n7. Before vs. after\n8. Important warning\n\n"
            f"Never confuse a label name (like :cond_false) with the opcode behavior (if-eqz means branch if register == 0).\n\n"
            f"{static_report}\n\n"
            f"User Question: {user_question}\n\n"
            f"Supplied Smali Code:\n```smali\n{smali_code}\n```"
        )