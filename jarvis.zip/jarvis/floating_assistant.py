from typing import Tuple
from kivy.clock import Clock
from jarvis.android_bridge import AndroidBridge
from jarvis.config import ConfigManager


class FloatingAssistantManager:
    """Controls the native Android floating overlay window and polls its quick actions."""

    def __init__(self, bridge: AndroidBridge, config: ConfigManager, on_command_callback):
        self.bridge = bridge
        self.config = config
        self.on_command_callback = on_command_callback
        self._poll_ev = Clock.schedule_interval(self._poll_commands, 0.5)

    def enable_floating_mode(self) -> Tuple[bool, str]:
        if not self.bridge.is_android:
            return False, "Floating overlay requires running on an Android device."

        if not self.bridge.can_draw_overlays():
            self.bridge.open_overlay_settings()
            return (
                False,
                "Overlay permission required. Please grant 'Display over other apps' in the Android settings screen that just opened, then toggle again.",
            )

        shown = self.bridge.show_floating_assistant()
        if shown:
            self.config.set("floating_assistant_enabled", True)
            return True, "Floating JARVIS overlay started."
        return False, "Could not start floating overlay."

    def disable_floating_mode(self) -> None:
        self.config.set("floating_assistant_enabled", False)
        self.bridge.hide_floating_assistant()

    def _poll_commands(self, _dt) -> None:
        cmd = self.bridge.poll_floating_command()
        if cmd and self.on_command_callback:
            self.on_command_callback(cmd)