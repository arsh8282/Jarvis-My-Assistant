import json
from typing import List, Dict
from kivy.utils import platform
from jarvis.utils import logger


class AndroidBridge:
    """
    Wraps Pyjnius calls to org.jarvis.bridge.JarvisBridge, JarvisFloatingService,
    and JarvisScreenCaptureHelper (supporting Android 10 through Android 15 / API 35).
    """

    def __init__(self):
        self.is_android = (platform == "android")
        self.activity = None
        self.j_bridge = None
        self.j_floating = None
        self.j_capture = None

        if self.is_android:
            try:
                from jnius import autoclass
                from android import activity as android_activity

                PythonActivity = autoclass("org.kivy.android.PythonActivity")
                self.activity = PythonActivity.mActivity
                self.j_bridge = autoclass("org.jarvis.bridge.JarvisBridge")
                self.j_floating = autoclass("org.jarvis.bridge.JarvisFloatingService")
                self.j_capture = autoclass("org.jarvis.bridge.JarvisScreenCaptureHelper")
                self.j_bridge.initTTS(self.activity)
                android_activity.bind(on_activity_result=self._on_android_activity_result)
            except Exception as e:
                logger.error(f"AndroidBridge initialization error: {e}")
                self.is_android = False

    def _on_android_activity_result(self, request_code, result_code, intent):
        if self.is_android and self.j_capture:
            try:
                if request_code == self.j_capture.REQUEST_MEDIA_PROJECTION:
                    self.j_capture.onActivityResult(self.activity, request_code, result_code, intent)
            except Exception as e:
                logger.error(f"MediaProjection activity result error: {e}")

    def request_media_projection(self) -> bool:
        if not self.is_android or not self.j_capture:
            return False
        try:
            return bool(self.j_capture.requestCapturePermission(self.activity))
        except Exception as e:
            logger.error(f"request_media_projection error: {e}")
            return False

    def is_media_projection_active(self) -> bool:
        if not self.is_android or not self.j_capture:
            return False
        try:
            return bool(self.j_capture.isProjectionActive())
        except Exception:
            return False

    def capture_media_projection_frame(self, out_path: str) -> str:
        if not self.is_android or not self.j_capture:
            return ""
        try:
            return str(self.j_capture.captureFrameToFile(out_path) or "")
        except Exception as e:
            logger.error(f"capture_media_projection_frame error: {e}")
            return ""

    def stop_media_projection(self) -> None:
        if self.is_android and self.j_capture:
            try:
                self.j_capture.stopProjection()
            except Exception:
                pass

    def save_secret(self, key: str, value: str) -> bool:
        if not self.is_android or not self.j_bridge:
            return False
        try:
            return bool(self.j_bridge.saveEncryptedSecret(self.activity, key, value))
        except Exception as e:
            logger.error(f"KeyStore save error: {e}")
            return False

    def load_secret(self, key: str) -> str:
        if not self.is_android or not self.j_bridge:
            return ""
        try:
            return str(self.j_bridge.loadEncryptedSecret(self.activity, key) or "")
        except Exception as e:
            logger.error(f"KeyStore load error: {e}")
            return ""

    def clear_secret(self, key: str) -> None:
        if self.is_android and self.j_bridge:
            try:
                self.j_bridge.clearEncryptedSecret(self.activity, key)
            except Exception:
                pass

    def speak(self, text: str, rate: float = 1.0, pitch: float = 1.0, flush: bool = True) -> bool:
        if not self.is_android or not self.j_bridge:
            logger.info(f"[TTS Simulated]: {text[:80]}...")
            return False
        try:
            return bool(self.j_bridge.speakText(text, float(rate), float(pitch), bool(flush)))
        except Exception as e:
            logger.error(f"TTS speak error: {e}")
            return False

    def stop_speaking(self) -> None:
        if self.is_android and self.j_bridge:
            try:
                self.j_bridge.stopTTS()
            except Exception:
                pass

    def start_speech_recognition(self, language: str = "en-IN") -> bool:
        if not self.is_android or not self.j_bridge:
            return False
        try:
            self.j_bridge.startListening(self.activity, language)
            return True
        except Exception as e:
            logger.error(f"Start listening failed: {e}")
            return False

    def stop_speech_recognition(self) -> None:
        if self.is_android and self.j_bridge:
            try:
                self.j_bridge.stopListening()
            except Exception:
                pass

    def get_speech_state(self) -> Dict[str, str]:
        if not self.is_android or not self.j_bridge:
            return {"status": "ERROR", "text": "", "error": "Native Android SpeechRecognizer unavailable on desktop."}
        try:
            raw = self.j_bridge.getSpeechStateJson()
            return json.loads(raw)
        except Exception as e:
            return {"status": "ERROR", "text": "", "error": str(e)}

    def can_draw_overlays(self) -> bool:
        if not self.is_android or not self.j_bridge:
            return False
        try:
            return bool(self.j_bridge.canDrawOverlays(self.activity))
        except Exception:
            return False

    def open_overlay_settings(self) -> None:
        if self.is_android and self.j_bridge:
            try:
                self.j_bridge.openOverlaySettings(self.activity)
            except Exception as e:
                logger.error(f"Cannot open overlay settings: {e}")

    def show_floating_assistant(self) -> bool:
        if not self.is_android or not self.j_floating:
            return False
        try:
            if not self.can_draw_overlays():
                return False
            self.j_floating.showFloatingOverlay(self.activity)
            return True
        except Exception as e:
            logger.error(f"Failed starting floating overlay: {e}")
            return False

    def hide_floating_assistant(self) -> None:
        if self.is_android and self.j_floating:
            try:
                self.j_floating.hideFloatingOverlay()
            except Exception:
                pass

    def poll_floating_command(self) -> str:
        if not self.is_android or not self.j_floating:
            return ""
        try:
            return str(self.j_floating.pollPendingCommand() or "")
        except Exception:
            return ""

    def get_installed_apps(self) -> List[Dict[str, str]]:
        if not self.is_android or not self.j_bridge:
            return [
                {"name": "Settings (Simulated)", "package": "com.android.settings"},
                {"name": "Chrome (Simulated)", "package": "com.android.chrome"},
            ]
        try:
            raw = self.j_bridge.getInstalledAppsJson(self.activity)
            return json.loads(raw)
        except Exception as e:
            logger.error(f"Failed listing installed apps: {e}")
            return []

    def launch_app(self, package_name: str) -> bool:
        if not self.is_android or not self.j_bridge:
            return False
        try:
            return bool(self.j_bridge.launchPackage(self.activity, package_name))
        except Exception as e:
            logger.error(f"Failed launching package {package_name}: {e}")
            return False