from kivy.utils import get_color_from_hex

THEME = {
    "bg_dark": get_color_from_hex("#070B19"),
    "bg_card": get_color_from_hex("#112240"),
    "bg_input": get_color_from_hex("#1A2F4C"),
    "accent_cyan": get_color_from_hex("#00E5FF"),
    "accent_blue": get_color_from_hex("#2979FF"),
    "text_primary": get_color_from_hex("#E6F1FF"),
    "text_secondary": get_color_from_hex("#8892B0"),
    "danger": get_color_from_hex("#FF5252"),
    "success": get_color_from_hex("#00E676"),
}